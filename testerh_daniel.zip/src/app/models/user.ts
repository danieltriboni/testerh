export class User {
    name: string | undefined;
    email: string | undefined;
    cpf: string | undefined;
    empresa: string | undefined;
    cnpj: string | undefined;
    cep: string | undefined;
    endereco: string | undefined;
    complemento: string | undefined;
    bairro: string | undefined;
    cidade: string | undefined;
    estado: string | undefined;
    celular: string | undefined;
    password: string | undefined;
    level: number | undefined
}